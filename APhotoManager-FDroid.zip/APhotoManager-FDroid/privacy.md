# Privacy Policy

This app "A Photo Manager" is an absolutely Open Source app. All services the software provides comes at no cost and is intended for use as is.

## Data collection and Usage

You can use this app to add personal informations (geo data and comments) to your local photos which will also been transfered into android-s local media database for faster search and that will also become visible to other android apps.

This app will never transfer local photos or content of android-s local media database to any other computer/server. 

Other Android Apps like "goolge photos" might transfer the photos with personal informations to other computer/server.

This app does not collect any other personal informoation.

If you use the geographic map then map data may be fetched from OpenStreetMap servers so OpenStreetMap servers may be logging your ip address, date/time and the geographic area you are currently looking at.

Each mapdata piece is only loaded once and then locally stored.

## Changes to This Privacy Policy

This privacy policy may be updated from time to time. Thus, it is advisable to review this document periodically for any changes. . These changes are effective immediately after the privacy policy document is updated

## Contact Us

If you have any questions or suggestions about this Privacy Policy, do not hesitate to contact the developer via [github](https://github.com/k3b/APhotoManager)
